package com.example.aditya.tourguidesarpass;

/**
 * Created by aditya on 3/5/2017.
 */

public class Word {
    /** Default translation for the word_list */
    private String mName;

    /** Miwok translation for the word_list */
    private String mDescription;

    /** Image resource ID for the word_list */
    private int mImageResourceId = NO_IMAGE_PROVIDED;

    /** Constant value that represents no image was provided for this word_list */
    private static final int NO_IMAGE_PROVIDED = -1;

    /**
     * Create a new com.example.aditya.tourguide.Word object.
     *
     * @param name is the word_list in a language that the user is already familiar with
     *                           (such as English)
     * @param description is the word_list in the Miwok language
     */
    public Word(String name, String description) {
        mDescription = description;
        mName = name;
    }

    /**
     * Create a new com.example.aditya.KasolGuide.Word object.
     *
     * @param name is the word_list in a language that the user is already familiar with
     *                           (such as English)
     * @param description is the word_list in the Miwok language
     * @param imageResourceId is the drawable resource ID for the image associated with the word_list
     */
    public Word(String description, String name, int imageResourceId) {
        mDescription = description;
        mName = name;
        mImageResourceId = imageResourceId;
    }

    /**
     * Get the default translation of the word_list.
     */
    public String getdescription() {
        return mDescription;
    }

    /**
     * Get the Miwok translation of the word_list.
     */
    public String getname() {
        return mName;
    }

    /**
     * Return the image resource ID of the word_list.
     */
    public int getImageResourceId() {
        return mImageResourceId;
    }

    /**
     * Returns whether or not there is an image for this word_list.
     */
    public boolean hasImage() {
        return mImageResourceId != NO_IMAGE_PROVIDED;
    }


}

