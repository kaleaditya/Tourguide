package com.example.aditya.tourguidesarpass;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find the View that shows the historical category
        TextView historical = (TextView) findViewById(R.id.historical);

        // Set a click listener on that View
        historical.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the historical category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link historicalActivity}
                Intent historicalIntent = new Intent(MainActivity.this, historical.class);

                // Start the new activity
                startActivity(historicalIntent);
            }
        });

        // Find the View that shows the event category
        TextView Events = (TextView) findViewById(R.id.activity_event);

        // Set a click listener on that View
        Events.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Event category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link EventActivity}
                Intent eventIntent = new Intent(MainActivity.this,Events.class);

                // Start the new activity
                startActivity(eventIntent);
            }
        });

        // Find the View that shows the place category
        TextView PublicPlace = (TextView) findViewById(R.id.activity_public_places);

        // Set a click listener on that View
        PublicPlace.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the places category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link PlaceActivity}
                Intent PublicPlaceIntent = new Intent(MainActivity.this, PublicPlace.class);

                // Start the new activity
                startActivity(PublicPlaceIntent);
            }
        });

        // Find the View that shows the Item category
        TextView Restaurant = (TextView) findViewById(R.id.activity_femous_items);

        // Set a click listener on that View
        Restaurant.setOnClickListener(new View.OnClickListener() {
            // The code in this method will be executed when the Item category is clicked on.
            @Override
            public void onClick(View view) {
                // Create a new intent to open the {@link ItemActivity}
                Intent RestaurantIntent = new Intent(MainActivity.this, Restaurants.class);

                // Start the new activity
                startActivity(RestaurantIntent);
            }
        });
    }
    }

